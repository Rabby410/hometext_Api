<?php

namespace App\Http\Resources;

use App\Manager\ImageUploadManager;
use App\Manager\PriceManager;
use App\Models\Product;
use App\Models\ProductPhoto;
use App\Utility\Date;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Ramsey\Uuid\Rfc4122\NilUuid;

class ProductDetailsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $price_manager = PriceManager::calculate_sell_price(
            $this->price,
            $this->discount_percent,
            $this->discount_fixed,
            $this->discount_start,
            $this->discount_end
        );

        // Handle division by zero for profit_percentage
        $profitPercentage = 0;
        if ($price_manager['price'] !== 0) {
            $profitPercentage = number_format(
                (($price_manager['price'] - $this->cost) / $price_manager['price'] * 100),
                NilUuid::RFC_4122
            );
        }

        return [
            'id' => $this->id,
            'name' => $this->name,
            'slug' => $this->slug,
            'cost' => $this->cost . PriceManager::CURRENCY_SYMBOL,
            'price' => number_format($this->price) . PriceManager::CURRENCY_SYMBOL,
            'original_price' => $this->price,
            'price_formula' => $this->price_formula,
            'field_limit' => $this->field_limit,
            'sell_price' => $price_manager,
            'sku' => $this->sku,
            'stock' => $this->stock,
            'isFeatured' => $this->isFeatured,
            'isNew' => $this->isNew,
            'isTrending' => $this->isTrending,
            'status' => $this->status == Product::STATUS_ACTIVE ? 'Active' : 'Inactive',
            'discount_fixed' => $this->discount_fixed . PriceManager::CURRENCY_SYMBOL,
            'discount_percent' => $this->discount_percent . '%',
            'description' => $this->description,
            'created_at' => $this->created_at ? $this->created_at->toDayDateTimeString() : null,
            'updated_at' => $this->updated_at ? ($this->updated_at == $this->created_at ? 'Not Updated' : $this->updated_at->toDayDateTimeString()) : null,
            'discount_start' => $this->discount_start != null ? Carbon::create($this->discount_start)->toDayDateTimeString() : null,
            'discount_end' => $this->discount_end != null ? Carbon::create($this->discount_end)->toDayDateTimeString() : null,
            'discount_remaining_days' => Date::calculate_discount_remaining_date($this->discount_remaining_days),
            'profit' => $price_manager['price'] - $this->cost,
            'profit_percentage' => $profitPercentage, // Handle division by zero
            'brand' => $this->brand?->name,
            'category' => $this->category,
            'sub_category' => $this->sub_category?->name,
            'child_sub_category' => $this->child_sub_category?->name,
            'supplier' => $this->supplier ? $this->supplier?->name . ' ' . $this->supplier?->phone : null,
            'country' => $this->country?->name,
            'created_by' => $this->created_by?->name,
            'updated_by' => $this->updated_by?->name,
            'primary_photo' => ImageUploadManager::prepareImageUrl(ProductPhoto::THUMB_PHOTO_UPLOAD_PATH, $this->primary_photo?->photo),
            'attributes' => ProductAttributeListResource::collection($this->product_attributes),
            'photos' => ProductPhotoListResource::collection($this->photos),
        ];
    }
}
